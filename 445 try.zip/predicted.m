function I=predicted(po,COL)%po=position,col=color image
I=insertShape(COL,'Rectangle',po,'Color','green');
end
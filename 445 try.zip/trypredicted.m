videoReader = vision.VideoFileReader('Test2.mp4');
videoPlayer = vision.VideoPlayer('Name', 'Gausian Background Subtraction');
videoPlayer.Position(3:4) = [1400,800];
position=[0 0 0 0];%Trajectory position
while ~isDone(videoReader)
    frame=step(videoReader);
    grayframe = im2double(rgb2gray(frame));
    diff=grayframe-BG;
    FG_mask=diff>0.15;
    FG_mask=bwareaopen(FG_mask,3);
    FG=FG_mask.*grayframe;
    FG=imopen(FG,strel('disk',2));
    %FG=imerode(FG,strel('disk',1));
    FG=imdilate(FG,strel('disk',10));
    FG=imclose(FG,strel('disk',2));
    FG=im2bw(FG);
     [Label,Number]=bwlabel(FG);
    region=regionprops(Label,'all');
    [r,c]=size(FG);
    onlyball=zeros(r,c);
    
    for i=1:Number
        item=double(Label==i);
        if(region(i).Area<950)
            onlyball=onlyball+item;
        end
    end
    
    [BW2,frame_layer2] = createMasklayer2(frame);
    FG_layer2 = im2bw(rgb2gray(frame_layer2));
    FG_layer2 =imerode(FG_layer2 ,strel('disk',2));
    FG_layer2 =imdilate(FG_layer2 ,strel('disk',6));
    
    
    [BW,frame_rgbSegmented] = createMasknew2(frame);
    FG_segment = im2bw(rgb2gray(frame_rgbSegmented));
    FG_segment(1:160,:)=0;
    FG_segment(832:1080,:)=0;
    FG_segment(:,1:250)=0;
    FG_segment(:,1650:1920)=0;
    FG_segment=imerode(FG_segment,strel('disk',2));
    FG_segment=imdilate(FG_segment,strel('disk',6));
    %apply and oporator on both the gausian and the color segmented object
    NFG = bitand(onlyball, FG_segment);
    % Use morphological opening to remove noise in the FG
    filteredFG = imopen(NFG, strel('disk', 3));
    filteredFG=imdilate(filteredFG,strel('disk',3));
    
    [vid,posi]=newdetectobject(filteredFG,frame,50);
    [vidl2,posil2]=newdetectobject(FG_layer2,frame,50);
    [porow,pocol]=size(position);
    [l2row,l2col]=size(posil2);
    
    if posi(1,1)~=0
    position=cat(1,position,posi);
    else
        for j=1:l2row
            xdir=position(porow,2)+(position(porow,4)/2);
            ydir=position(porow,1)+(position(porow,3)/2);
            xdirl2=posil2(j,2)+(posil2(j,4)/2);
            ydirl2=posil2(j,1)+(posil2(j,3)/2);
            r=sqrt((xdir-xdirl2).^2+(ydir-ydirl2).^2);
            if r<60
                position=cat(1,position,posil2(j,:));
                vid=predicted(posil2(j,:),frame);
            end
        end
    end
    step(videoPlayer,vid);
end
release(videoPlayer)
%%
showTrajectory(BG,position);
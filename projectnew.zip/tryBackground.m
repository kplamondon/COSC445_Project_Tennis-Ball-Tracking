BG=GetBackground('Test2.mp4',390);%video name and number of frame   really slow!!!!
%%
videoReader = vision.VideoFileReader('Test2.mp4');
videoPlayer = vision.VideoPlayer('Name', 'Gausian Background Subtraction');
position=[0 0 0 0];%Trajectory position
while ~isDone(videoReader)
    frame=step(videoReader);
    grayframe = im2double(rgb2gray(frame));
    diff=grayframe-BG;
    FG_mask=diff>0.12;
    FG_mask=bwareaopen(FG_mask,3);
    FG=FG_mask.*grayframe;
    FG=imopen(FG,strel('disk',2));
    FG=imdilate(FG,strel('disk',5));
    FG=im2bw(FG);
     [Label,Number]=bwlabel(FG);
    region=regionprops(Label,'all');
    [r,c]=size(FG);
    onlyball=zeros(r,c);
    for i=1:Number
        item=double(Label==i);
        if(region(i).Area<420)
            onlyball=onlyball+item;
        end
    end
    [BW,frame_rgbSegmented] = createMask2(frame);
    FG_segment = im2bw(rgb2gray(frame_rgbSegmented));
    FG_segment(1:180,:)=0;
    FG_segment(832:1080,:)=0;
    FG_segment(:,1:250)=0;
    FG_segment(:,1650:1920)=0;
    FG_segment=imerode(FG_segment,strel('disk',2));
    FG_segment=imdilate(FG_segment,strel('disk',6));
    %apply and oporator on both the gausian and the color segmented object
    NFG = bitand(onlyball, FG_segment);
    % Use morphological opening to remove noise in the FG
    filteredFG = imopen(NFG, strel('disk', 3));
    filteredFG=imdilate(filteredFG,strel('disk',3));
    [vid,posi]=detectobject(filteredFG,frame,200);
    position=cat(1,position,posi);
    step(videoPlayer,vid);
end
release(videoPlayer);
%%
showTrajectory(BG,position);

